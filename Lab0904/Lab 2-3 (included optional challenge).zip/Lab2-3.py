# By submitting this assignment, I agree to the following:
#  “Aggies do not lie, cheat, or steal, or tolerate those who do”
#  “I have not given or received any unauthorized aid on this assignment”
#
# Name: 		Anh Nghia Hoang
# Section:		506
# Assignment:	Lab 2 - program 3
# Date:		    04 09 2018
import math
t1=30
t2=45
d1=50
d2=615
s=(d2-d1)/(t2-t1)
t37=37-30
d37=s*t37+50
print('the distant of the car at 37s is', d37)